# Soulcode_Projeto_Python
Esse repositório contém um projeto da simulação de um sistema de uma oficina mecânica, onde o cliente pode comprar produtos e serviços através de seu computador. 
